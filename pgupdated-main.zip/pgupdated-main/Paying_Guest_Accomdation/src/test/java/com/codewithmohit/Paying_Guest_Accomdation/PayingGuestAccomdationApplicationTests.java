package com.codewithmohit.Paying_Guest_Accomdation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayingGuestAccomdationApplicationTests {

	@Test
	void contextLoads() {
	}

}
