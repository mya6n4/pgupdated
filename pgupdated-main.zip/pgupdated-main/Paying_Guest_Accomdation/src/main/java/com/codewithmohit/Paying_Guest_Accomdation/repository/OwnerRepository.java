package com.codewithmohit.Paying_Guest_Accomdation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codewithmohit.Paying_Guest_Accomdation.entites.Owner;
public interface OwnerRepository extends JpaRepository<Owner, Long> {}