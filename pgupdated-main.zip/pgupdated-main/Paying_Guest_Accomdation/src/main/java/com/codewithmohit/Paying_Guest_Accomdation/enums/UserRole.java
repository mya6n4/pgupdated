package com.codewithmohit.Paying_Guest_Accomdation.enums;

public enum UserRole {
    TENANT,
    OWNER,
    ADMIN
}