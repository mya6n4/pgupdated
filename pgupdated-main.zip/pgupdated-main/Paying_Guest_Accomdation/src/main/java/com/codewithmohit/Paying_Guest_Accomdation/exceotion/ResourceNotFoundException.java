package com.codewithmohit.Paying_Guest_Accomdation.exceotion;

public class ResourceNotFoundException extends RuntimeException {
public ResourceNotFoundException(String message) { super(message); }
}
