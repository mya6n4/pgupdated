package com.codewithmohit.Paying_Guest_Accomdation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayingGuestAccomdationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayingGuestAccomdationApplication.class, args);
	}

}
